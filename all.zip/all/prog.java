Class abc
{
Public void main()
{
System.out.println("Hello World");
}
}